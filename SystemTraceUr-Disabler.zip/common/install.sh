#!/system/bin/sh
# SystemTraceUr Disabler by INFINITY LOOPER (InfinityLoop-er @ GitHub)
# Idea forked from @NotZeetaa

ui_print ""
ui_print " SystemTraceur Disabler Selector: "
sleep 2
ui_print ""
ui_print " Volume + = Switch option "
ui_print ""
sleep 1
ui_print " Volume - = Select option "
ui_print ""
ui_print ""
ui_print " 1- Disable "
ui_print ""
sleep 0.4
ui_print " 2- Enable "
ui_print ""
sleep 0.4
ui_print " 3- Exit "
ui_print ""
ui_print " Select which option you want:"
ui_print ""
SD=1
while true
do
ui_print "  $SD"
if $VKSEL 
then
SD=$((SD + 1))
else 
break
fi
if [ $SD -gt 3 ]
then
SD=1
fi
done

case $SD in
1 ) FCTEXTAD1="Disable";;
2 ) FCTEXTAD1="Enable";;
3 ) FCTEXTAD1="Exit";;
esac

ui_print ""
ui_print " Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "Disable" ]]
then
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/SystemTraceUr-Disabler/main/STDisabler"
# Do install-time script execution
ui_print " Executing during live boot..."
sh "$MODPATH/system/bin/STDisabler" &> /dev/null
ui_print ""

elif [[ "$FCTEXTAD1" == "Enable" ]]
then
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/SystemTraceUr-Disabler/main/STEnabler"
# Do install-time script execution
ui_print " Executing during live boot..."
sh "$MODPATH/system/bin/STEnabler" &> /dev/null
ui_print ""

elif [[ "$FCTEXTAD1" == "Exit" ]]
then

ui_print ""
ui_print " Done!"
ui_print ""
fi