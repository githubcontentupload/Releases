#!/system/bin/sh
# XTweak 2021
# Variables
Path=/storage/emulated/0
if [ ! -d $Path/XTweak ]; then
 mkdir -p $Path/XTweak
fi;
XT=$Path/XTweak
#
ui_print ""
ui_print "[*] XTweak Modes Selector: "
sleep 2
ui_print ""
ui_print "[*] Volume + = Switch × Volume - = Select "
ui_print ""
sleep 1.5
ui_print " 1- Accumulator (Reduces cpu and gpu speeds to conserve more battery) "
ui_print ""
sleep 0.8
ui_print " 2- Potency (Improve system's latency to provide speed on your phone) "
ui_print ""
sleep 0.8
ui_print " 3- Equalizer (Performs equally for battery and performance) "
ui_print ""
sleep 0.8
ui_print " 4- Output (Maximizes cpu and gpu speeds to attain highest level performance) "
ui_print ""
ui_print "[*] Select which mode you want:"
ui_print ""
SM=1
while true
do
ui_print "  $SM"
if $VKSEL 
then
SM=$((SM + 1))
else 
break
fi
if [ $SM -gt 4 ]
then
SM=1
fi
done

case $SM in
1 ) FCTEXTAD1="Accumulator";;
2 ) FCTEXTAD1="Potency";;
3 ) FCTEXTAD1="Equalizer";;
4 ) FCTEXTAD1="Output";;
esac

ui_print ""
ui_print "[*] Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "Accumulator" ]]
then
echo "0" > $XT/mode.txt

elif [[ "$FCTEXTAD1" == "Potency" ]]
then
echo "2" > $XT/mode.txt

elif [[ "$FCTEXTAD1" == "Equalizer" ]]
then
echo "1" > $XT/mode.txt

elif [[ "$FCTEXTAD1" == "Output" ]]
then
echo "3" > $XT/mode.txt

ui_print ""
ui_print " [*] Done!"
ui_print ""
fi

ui_print " --- Additional Notes --- "
ui_print ""
ui_print "[*] Reboot is required"
ui_print ""
ui_print "[*] Do not use XTweak with other optimizer modules"
ui_print ""
ui_print "[*] To open CLI(Command Line). Type (su -c x-cli) in Termux or similar apps"
ui_print "[*] Report issues to @tweak_projects_discuss on Telegram"
ui_print ""
ui_print "[*] Contact @infinity_looper for direct support"
ui_print ""