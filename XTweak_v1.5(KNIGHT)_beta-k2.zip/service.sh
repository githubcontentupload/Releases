#!/system/bin/sh
# XTweak 2021
# Wait for boot to finish completely
sleep_until_complete_boot() {
until [[ "$(getprop sys.boot_completed)" -eq 1 ]] || [[ "$(getprop dev.bootcomplete)" -eq 1 ]]; do
       sleep 2
done
}

sleep_until_complete_boot

# sleep 60s
sleep 60

# Apply tweak
xtweak