#!/system/bin/sh
# dex2oat optimizer 2021
#
ui_print ""
ui_print "[*] dex2oat optimizer basically triggers the android built-in dalvik optimizer."
sleep 2.5
ui_print ""
ui_print "[*] This process can take up to 10 mins depending upon how much apps you have in your android device."
sleep 2
ui_print ""
ui_print "[*] Do you want to continue? "
sleep 2
ui_print ""
ui_print "[*] Volume + = Switch × Volume - = Select "
ui_print ""
sleep 1.5
ui_print " 1- Yes "
ui_print ""
sleep 0.8
ui_print " 2- No "
ui_print ""
ui_print "[*] Select option:"
ui_print ""
DO=1
while true
do
ui_print "  $DO"
if $VKSEL 
then
DO=$((DO + 1))
else 
break
fi
if [ $DO -gt 2 ]
then
DO=1
fi
done

case $DO in
1 ) FCTEXTAD1="Yes";;
2 ) FCTEXTAD1="No";;
esac

ui_print ""
ui_print "[*] Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "Yes" ]]
then
rm -rf "$MODPATH"/random

elif [[ "$FCTEXTAD1" == "No" ]]
then
exit 1

ui_print ""
ui_print " [*] Done!"
ui_print ""
fi

ui_print " --- Additional Notes --- "
ui_print ""
ui_print "[*] Reboot is needed"
ui_print ""
ui_print "[*] Don't try to use dex2oat optimizer with other dalvik optimizer"
ui_print ""
ui_print "[*] Report issues to @tweak_projects_discuss on Telegram"
ui_print ""
ui_print "[*] Contact @infinity_looper for direct support"
ui_print ""