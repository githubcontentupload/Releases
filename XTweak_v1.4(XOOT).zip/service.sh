#!/system/bin/sh
# XTweak 2021
# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 1
done

# Sleep 29s
sleep 29

# Path Log
Path=/storage/emulated/0
if [ ! -d $Path/XTweak ]; then
 mkdir -p $Path/XTweak
fi;

# Cleaning junk
x-clean

# Apply doze script
x-doze

# Apply cgroup script
x-cgroup

# Apply sqlite script
x-sqlite

# Apply zipalign script
x-zipalign

# Apply main script
xtweak

# Log the success
x-log