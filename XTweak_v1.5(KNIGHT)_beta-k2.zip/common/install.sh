#!/system/bin/sh
# XTweak 2021
# Variables
Path=/sdcard
if [ ! -d $Path/XTweak ]; then
 mkdir -p $Path/XTweak
fi;
XT=$Path/XTweak
#
ui_print ""
ui_print "[*] XTweak Modes Selector: "
sleep 2
ui_print ""
ui_print "[*] Volume + = Switch × Volume - = Select "
ui_print ""
sleep 1.5
ui_print " 1- Auto (Automatically changes modes based on user behavior) "
ui_print ""
sleep 0.8
ui_print " 2- Accumulator (Reduces cpu and gpu speeds to conserve more battery) "
ui_print ""
sleep 0.8
ui_print " 3- Equalizer (Performs equally for battery and performance) "
ui_print ""
sleep 0.8
ui_print " 4- Potency (Improve system's latency to provide speed on your phone) "
ui_print ""
sleep 0.8
ui_print " 5- Output (Maximizes cpu and gpu speeds to attain highest level performance) "
ui_print ""
sleep 0.8
ui_print "[*] Select which mode you want:"
ui_print ""
SM=1
while true
do
ui_print "  $SM"
if $VKSEL 
then
SM=$((SM + 1))
else 
break
fi
if [ $SM -gt 5 ]
then
SM=1
fi
done

case $SM in
1 ) FCTEXTAD1="Auto";;
2 ) FCTEXTAD1="Accumulator";;
3 ) FCTEXTAD1="Equalizer";;
4 ) FCTEXTAD1="Potency";;
5 ) FCTEXTAD1="Output";;
esac

ui_print ""
ui_print "[*] Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "Auto" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "4" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Accumulator" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "0" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Equalizer" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "1" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Potency" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "2" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Output" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "3" 2>/dev/null
fi

ui_print " --- Additional Notes --- "
ui_print ""
ui_print "[*] Reboot is required"
ui_print ""
ui_print "[*] Do not use XTweak with other optimizer modules"
ui_print ""
ui_print "[*] (su -c x-menu) to open XTweak Menu in Termux"
ui_print ""
ui_print "[*] Report issues to @tweak_projects_discuss on Telegram"
ui_print ""
ui_print "[*] Contact @infinity_looper for direct support"
ui_print ""