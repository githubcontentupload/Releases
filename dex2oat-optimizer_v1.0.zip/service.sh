#!/system/bin/sh
# dex2oat optimizer 2021
# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 1
done

# Sleep 60s
sleep 60

# Apply dalvik script
x-dex2oat