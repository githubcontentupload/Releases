#!/system/bin/sh
# dex2oat optimizer 2021
LATESTARTSERVICE=true
DEBUG=true
#
awk '{print}' "$MODPATH"/dex2oat_banner
ui_print ""     
ui_print "[*] dex2oat optimizer, a powerful dalvik system and user packages optimizer."
ui_print ""
sleep 3
ui_print "[*] It will optimize android runtime performance and app-opening speed by optimizing apps packages with the help of android built-in dalvik optimizer."
ui_print ""
sleep 4
ui_print "[*] If you really like my projects, consider sharing them with your friends. It means alot to me.♥️"
sleep 3
#
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
}
#
SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR"/functions.sh