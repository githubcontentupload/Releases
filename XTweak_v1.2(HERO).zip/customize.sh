#!/system/bin/sh
# XTweak 2021

ui_print ""
ui_print " --- XTweak ---"
ui_print ""
ui_print " [*] Setting executable permissions..."
set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755

ui_print ""
ui_print " --- Additional Notes ---"
ui_print ""
ui_print " [*] Reboot is required"
ui_print " [*] Do not use XTweak with other optimizer modules"
ui_print " [*] Report issues to @tweak_projects_discuss on Telegram"
ui_print " [*] Contact @infinity_looper for direct support"
ui_print ""
