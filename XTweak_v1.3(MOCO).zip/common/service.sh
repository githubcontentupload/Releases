#!/system/bin/sh
# XTweak 2021
# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 1
done

# Sleep 60s
sleep 60

# Cleaning trash
rm -f /data/*.log
rm -rf /data/vendor/wlan_logs
rm -f /data/*.txt
rm -f /cache/*.apk
rm -f /data/anr/*
rm -f /data/backup/pending/*.tmp
rm -f /data/cache/*.*
rm -f /data/data/*.log
rm -f /data/data/*.txt
rm -f /data/log/*.log
rm -f /data/log/*.txt
rm -f /data/local/*.apk
rm -f /data/local/*.log
rm -f /data/local/*.txt
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -f /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/* 
rm -rf /sdcard/LOST.DIR 
rm -rf /sdcard/found000
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/ramdump

# Apply tweak
xtweak