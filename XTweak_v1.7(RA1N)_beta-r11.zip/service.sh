#!/system/bin/sh
# XTweak 2021
BASEDIR="$(dirname $(readlink -f "$0"))"
SCRIPT_DIR="$BASEDIR/script"
# Wait for boot to finish completely
sleep_until_complete_boot() {
until [[ "$(getprop sys.boot_completed)" -eq 1 ]] || [[ "$(getprop dev.bootcomplete)" -eq 1 ]]; do
       sleep 2
done
}

sleep_until_complete_boot

# Start the init service for uperf
sh $BASEDIR/initsvc_uperf.sh

# Wait some time before init is completed
sleep 30

# Apply tweak
xtweak