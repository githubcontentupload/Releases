#!/system/bin/sh
# XTweak by INFINITY LOOPER (InfinityLoop-er @ GitHub)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s) as I did
DEBUG=true
if [[ -d "/data/adb/modules/xtweak" ]]; then
    rm -R "/data/adb/modules/xtweak"
fi
total_ram=$(free -m | awk '/Mem:/{print $2}')
# Fetch the device SDK
sdk=$(getprop ro.build.version.sdk)
if [[ $sdk == "" ]]; then
    sdk=$(getprop ro.vendor.build.version.sdk)
elif [[ $sdk == "" ]]; then
      sdk=$(getprop ro.vndk.version)
fi
awk '{print}' "$MODPATH"/common/xtweak_banner
sleep 3
ui_print " XTweak is a universal powerful forcefulness magisk module aim to give you best performance plus battery as a daily driver"
ui_print ""
sleep 3
ui_print " It will optimize your overall performance, battery and ram usage management"
ui_print ""
sleep 3
ui_print " If you love it, please consider sharing it, it means a lot to me ❤️"
ui_print ""
sleep 3
ui_print " Credits:"
ui_print ""
sleep 2
ui_print " KTweak by Draco (tytydraco @ GitHub)"
ui_print ""
sleep 1.5
ui_print " Thanks to Eight (iamlazy123 @ GitHub)"
sleep 1.5
ui_print ""
ui_print " Thanks to pedro (pedrozzz0 @ GitHub)"
sleep 1.8
ui_print ""
ui_print " qti-mem-opt by Matt Yang (yc9559 @ GitHub)"
ui_print ""
sleep 1.1
ui_print " Thanks to HafiZziq @ GitHub"
ui_print ""
sleep 1
ui_print " Thanks to Kartik (TheHitman7 @ Github)"
ui_print ""
sleep 1.1
ui_print " Thanks to Dan (Paget96 @ xda-developers)"
ui_print ""
sleep 1.5
ui_print " And a special thanks to these devs for making me use their projects to make this project more awesome and also the devs within who helped them too♥️"
sleep 3.5
ui_print ""

moddir=/data/adb/modules

if [[ -d "$moddir"/injector ]]
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/Pulsar_Engine ]]
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/AGNi_Game_Unlock_CODm ]]
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/Pubg_extrem ]]
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/zeetaatweaks ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/ZTS ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/gaming ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/AGNi_Game_Unlock_PUBG ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/smext ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/fkm_spectrum_injector ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/NetworkTweak ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/lazy ]] 
then 
    ui_print " A conflicting module/app is installed, please remove and then install King Tweaks again."
    ui_print ""

elif [[ -d "$moddir"/toolbox8 ]] 
then 
    ui_print " A conflicting module/app is installed, please remove and then install King Tweaks again."
    ui_print ""

elif [[ -d "$moddir"/MAGNETAR ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/MAGNE ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/FDE ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ "$(pm list package feravolt)" ]] 
then
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/ktweak ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ "$(pm list package ktweak)" ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/lspeed ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ "$(pm list package magnetarapp)" ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ "$(pm list package lsandroid)" ]] 
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/sqinjector ]]    
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/ZeroLAG ]]    
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""
    
elif [[ -d "$moddir"/dns_weareravens ]]    
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/nexus ]]    
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/high_perf_dac ]]    
then 
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ "$(pm list package kitana)" ]]
then
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""

elif [[ -d "$moddir"/flushram ]] 
then
    ui_print " A conflicting module or app is installed on device, please remove it for safety purposes"
    ui_print ""
fi

# setting permissions
set_perm_recursive "$MODPATH"/system/bin 0 0 0777 0755

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR"/functions.sh

ui_print " Cleaning stuff..."

if [[ "$(find /system -name "zipalign" -type f)" ]]; then
    rm -f "$MODPATH/system/bin/zipalign"
fi

if [[ "$(getprop ro.iorapd.enable)" != "true" ]] && [[ "$sdk" -gt "29" ]]; then
    sed -i '/ro.iorapd.enable/s/.*/ro.iorapd.enable=true/' "$MODPATH"/system.prop

else
    sed -i '63,64d' "$MODPATH"/system.prop
fi

ui_print ""
ui_print " XTweak log(s) are stored in internal storage/XTweak"
ui_print ""
sleep 2.5
ui_print " Consider saving the installation logs only in case of anything going wrong"
ui_print ""
sleep 1.9
ui_print " Your dalvik-cache will be wiped, so boot may take longer."
ui_print ""
sync

rm -rf /data/dalvik-cache
rm -rf /cache/dalvik-cache
ui_print " Reboot to the changes be applied."
ui_print ""
magiskhide disable; magiskhide enable; magiskhide add com.tencent.ig; magiskhide add com.epicgames.fortnite; magiskhide add com.vng.pubgmobile; magiskhide add com.pubg.krmobile; magiskhide add com.activision.callofduty.shooter