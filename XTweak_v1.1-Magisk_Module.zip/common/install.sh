#!/system/bin/sh
# XTweak by INFINITY LOOPER (InfinityLoop-er @ GitHub)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s).

ui_print ""
ui_print " XTweak Modes Selector: "
sleep 2
ui_print ""
ui_print " Volume + = Switch option "
ui_print ""
sleep 1
ui_print " Volume - = Select option "
ui_print ""
ui_print " 1- Accumulator (Reduces cpu and gpu speeds to conserve more battery) "
ui_print ""
sleep 0.4
ui_print " 2- Potency (Improve system's latency to provide speed on your phone) "
ui_print ""
sleep 0.4
ui_print " 3- Equalizer (Performs equally for battery and performance) "
ui_print ""
sleep 0.4
ui_print " 4- Output (Maximizes cpu and gpu speeds to attain highest level performance) "
ui_print ""
ui_print " Select which mode you want:"
ui_print ""
SM=1
while true
do
ui_print "  $SM"
if $VKSEL 
then
SM=$((SM + 1))
else 
break
fi
if [ $SM -gt 4 ]
then
SM=1
fi
done

case $SM in
1 ) FCTEXTAD1="Accumulator";;
2 ) FCTEXTAD1="Potency";;
3 ) FCTEXTAD1="Equalizer";;
4 ) FCTEXTAD1="Output";;
esac

ui_print ""
ui_print " Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "Accumulator" ]]
then
sed -i '12,13d' "$MODPATH"/service.sh
sed -i '14d' "$MODPATH"/service.sh
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/accumulator/xtweak"
# Do install-time script execution
ui_print " Executing during live boot..."
sh "$MODPATH/system/bin/xtweak" &> /dev/null
ui_print ""

elif [[ "$FCTEXTAD1" == "Potency" ]]
then
sed -i '11,13d' "$MODPATH"/service.sh
sed -i '14d' "$MODPATH"/service.sh
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/potency/xtweak"
# Do install-time script execution
ui_print " Executing during live boot..."
sh "$MODPATH/system/bin/xtweak" &> /dev/null
ui_print ""

elif [[ "$FCTEXTAD1" == "Equalizer" ]]
then
sed -i '11,12d' "$MODPATH"/service.sh
sed -i '14d' "$MODPATH"/service.sh
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/equalizer/xtweak"
# Do install-time script execution
ui_print " Executing during live boot... "
sh "$MODPATH/system/bin/xtweak" &> /dev/null
ui_print ""

elif [[ "$FCTEXTAD1" == "Output" ]]
then
sed -i '11,12d' "$MODPATH"/service.sh
sed -i '13d' "$MODPATH"/service.sh
ui_print " Fetching the latest script(s) and from GitHub... "
ui_print ""
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/output/xtweak"
# Do install-time script execution
ui_print " Executing during live boot..."
sh "$MODPATH/system/bin/xtweak" &> /dev/null

ui_print ""
ui_print " Done!"
ui_print ""
fi