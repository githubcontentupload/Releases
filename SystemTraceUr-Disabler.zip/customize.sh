#!/system/bin/sh
# XTweak by INFINITY LOOPER (InfinityLoop-er @ GitHub)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s) as I did
DEBUG=true
if [[ -d "/data/adb/modules/traceurdisabler" ]]; then
    rm -R "/data/adb/modules/traceurdisabler"
fi
if [[ -d "/data/adb/modules/traceurdisabler" ]]; then
    rm -R "/data/adb/modules/traceurdisabler/system/bin/traceurdisabler"
fi
awk '{print}' "$MODPATH"/common/traceurdisabler_banner

# setting permissions
set_perm_recursive "$MODPATH"/system/bin 0 0 0777 0755

SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR"/functions.sh
# sync
sync