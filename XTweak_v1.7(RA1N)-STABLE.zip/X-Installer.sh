#!/system/bin/sh
# XTweak 2021
# FULLY MODIFIED BY INFINITYLOOPER
# SOME TEMPLATE STUFF BY Zackptg5
LATESTARTSERVICE=true
DEBUG=true
SKIPMOUNT=false
SKIPUNZIP=1
MODDIR=/data/adb/modules
A=$(getprop ro.product.cpu.abi);
abort(){
  ui_print "$1"
  rm -rf $MODPATH 2>/dev/null
  cleanup
  rm -rf $TMPDIR 2>/dev/null
  exit 1
}
cleanup(){
rm -rf $MODPATH/addon 2>/dev/null
rm -rf $MODPATH/xtweak_banner 2>/dev/null
rm -rf $MODPATH/test 2>/dev/null
}
 busybox_installer() {
if [ "$A" = "$(echo "$A"|grep "arm64")" ]; then
wget -O "$MODPATH/system/xbin/busybox8" "https://github.com/mightylooper/XTweak/raw/main/busybox8"
mv -f $MODPATH/system/xbin/busybox8 $MODPATH/system/xbin/busybox;

elif [ "$A" = "$(echo "$A"|grep "armeabi")" ]; then
wget -O "$MODPATH/system/xbin/busybox7" "https://github.com/mightylooper/XTweak/raw/main/busybox7"
mv -f $MODPATH/system/xbin/busybox7 $MODPATH/system/xbin/busybox;

elif [ "$A" = "$(echo "$A"|grep "x86_64")" ]; then
wget -O "$MODPATH/system/xbin/busybox64" "https://github.com/mightylooper/XTweak/raw/main/busybox64"
mv -f $MODPATH/system/xbin/busybox64 $MODPATH/system/xbin/busybox;

elif [ "$A" = "$(echo "$A"|grep "x86")" ]; then
wget -O "$MODPATH/system/xbin/busybox86" "https://github.com/mightylooper/XTweak/raw/main/busybox86"
mv -f $MODPATH/system/xbin/busybox86 $MODPATH/system/xbin/busybox;
else
abort "[!] Can't detect arc of device."
fi
}
if [[ -e "/sdcard/XTweak" ]]; then
    rm -rf "/sdcard/XTweak"
fi
Path=/sdcard
if [ ! -d $Path/XTweak ]; then
 mkdir -p $Path/XTweak
fi
XT=$Path/XTweak
X_Installer() {
awk '{print}' "$MODPATH"/xtweak_banner
ui_print ""
sleep 3.3  
ui_print "[*] XTweak is a universal powerful forcefulness kernel tweaker."
ui_print ""
sleep 3.3
ui_print "[*] It will enhance the performance while conserving battery usage by adjusting various kernel parameters of your android device."
ui_print ""
sleep 3.3
ui_print "[*] If you really like my projects, consider sharing them with your friends. It means alot to me.♥️"
sleep 3.3
if [ -d $MODDIR/KTSR ]; then
ui_print ""
ui_print "[*] KTSR Module is present, disabled for security purposes."
touch $MODDIR/KSTR/disable

elif [ -d MODDIR/FDE ]; then
ui_print ""
ui_print "[*] FDE.AI Module is present, disabled for security purposes" 
touch $MODDIR/FDE/disable

elif [ -d $MODDIR/MAGNETAR ]; then
ui_print ""
ui_print "[*] MAGNETAR Module is present, disabled for security purposes."
touch $MODDIR/MAGNETAR/disable

elif [ -d $MODDIR/ZeetaaTweaks ]; then
ui_print ""
ui_print "[*] ZeetaaTweaks Module is present, disabled for security purposes."
touch $MODDIR/ZeetaaTweaks/disable

elif [ -d $MODDIR/KTSRPRO ]; then
ui_print ""
ui_print "[*] KTSR PRO Module is present, disabled for security purposes."
touch $MODDIR/KTSRPRO/disable

elif [ -d $MODDIR/ZTS ]; then
ui_print ""
ui_print "[*] ZTS Module is present, disabled for security purposes."
touch $MODDIR/ZTS/disable

elif [ -d $MODDIR/Pulsar_Engine ]; then
ui_print ""
ui_print "[*] Pulsar Engine Module is present, disabled for security purposes."
touch $MODDIR/Pulsar_Engine/disable

elif [ -d $MODDIR/ktweak ]; then
ui_print ""
ui_print "[*] KTweak Module is present, disabled for security purposes."
touch $MODDIR/ktweak/disable

elif [ -d $MODDIR/high_perf_dac ]; then
ui_print ""
ui_print "[*] HIGH PERFORMANCE Module is present, disabled for security purposes."
touch $MODDIR/high_perf_dac/disable

elif [ -d $MODDIR/fkm_spectrum_injector ]; then
ui_print ""
ui_print "[*] FKM Injector Module is present, disabled for security purposes."
touch $MODDIR/fkm_spectrum_injector/disable

elif [ -d $MODDIR/toolbox8 ]; then
ui_print ""
ui_print "[*] Pandora's Box Module is present, disabled for security purposes."
touch $MODDIR/MAGNETAR/disable

elif [ -d $MODDIR/lazy ]; then
ui_print ""
ui_print "[*] Lazy Tweaks Module is present, disabled for security purposes."
touch $MODDIR/lazy/disable

elif [[ "$(pm list package ktweak)" ]]; then
ui_print ""
ui_print "[*] KTweak App is present, uninstall it to prevent conflicts."

elif [[ "$(pm list package kitana)" ]]; then
ui_print ""
ui_print "[*] Kitana App is present, uninstall it to prevent conflicts."

elif [[ "$(pm list package magnetarapp)" ]]; then
ui_print ""
ui_print "[*] MAGNETAR App is present, uninstall it to prevent conflicts."

elif [[ "$(pm list package lsandroid)" ]]; then
ui_print ""
ui_print "[*] LSpeed App is present, uninstall it to prevent conflicts."

elif [[ "$(pm list package feravolt)" ]]; then
ui_print ""
ui_print "[*] FDE.AI App is present, uninstall it to prevent conflicts."
fi
# Unzipping and preparing wget
unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
unzip -o "$ZIPFILE" 'addon/*' -d $TMPDIR >&2

# Preparing test and rest settings
ui_print ""
ui_print "[*] Preparing compatibility test..."
ui_print ""
if [[ -d $MODDIR/busybox-ndk ]] || [[ -d $MODDIR/busybox-brutal ]] || [[ -e /system/xbin/busybox ]] || [[ -e /system/bin/busybox ]] || [[ -e /vendor/bin/busybox ]]; then
sleep 0.1
else
cp -af $MODPATH/system/bin/wget /system/bin/wget
chmod -R 755 "/system/bin/wget"
 busybox_installer
fi
touch $MODPATH/test
echo "1" > $MODPATH/test 
COMPT=$(cat $MODPATH/test)
if [[ "$COMPT" -eq "1" ]]; then
sleep 0.1
else
sleep 0.1
fi
if [ -d /data/adb/modules/xtweak ]; then
magiskhide disable
rm -rf /data/adb/modules/xtweak/system
rm -rf /data/adb/modules/xtweak/service.sh 
rm -rf /data/adb/modules/xtweak/system.prop
magiskhide enable
fi
ui_print "[*] Done checking compatibility, continuing to installation..."
ui_print ""
sleep 2
ui_print "[*] Fetching various utilities from cloud ☁️ "
ui_print ""
sleep 2
ui_print "[*] Installing..."
sleep 2
wget -O "$TMPDIR/addon/Volume-Key-Selector/tools/arm/keycheckarm" "https://github.com/mightylooper/XTweak/raw/main/keycheckarm"
mv -f $TMPDIR/addon/Volume-Key-Selector/tools/arm/keycheckarm $TMPDIR/addon/Volume-Key-Selector/tools/arm/keycheck;
wget -O "$TMPDIR/addon/Volume-Key-Selector/tools/x86/keycheckx86" "https://github.com/mightylooper/XTweak/raw/main/keycheckx86"
mv -f $TMPDIR/addon/Volume-Key-Selector/tools/x86/keycheckx86 $TMPDIR/addon/Volume-Key-Selector/tools/x86/keycheck;
. $TMPDIR/addon/Volume-Key-Selector/install.sh
mode_select
}
mode_select() {
ui_print ""
ui_print "[*] XTweak Modes Selector: "
sleep 2
ui_print ""
ui_print "[*] Volume + = Switch × Volume - = Select "
ui_print ""
sleep 1.5
ui_print " 1- Auto X (Automatically changes modes based on user behavior) "
ui_print ""
sleep 0.8
ui_print " 2- Accumulator (Reduces cpu and gpu speeds to conserve more battery) "
ui_print ""
sleep 0.8
ui_print " 3- Equalizer (Performs equally for battery and performance) "
ui_print ""
sleep 0.8
ui_print " 4- Potency (Improve system's latency to provide speed on your phone) "
ui_print ""
sleep 0.8
ui_print " 5- Output (Maximizes cpu and gpu speeds to attain highest level performance) "
ui_print ""
sleep 0.8
ui_print "[*] Select which mode you want:"
ui_print ""
SM=1
while true
do
ui_print "$SM"
if $VKSEL 
then
SM=$((SM + 1))
else 
break
fi
if [ $SM -gt 5 ]
then
SM=1
fi
done

case $SM in
1 ) FCTEXTAD1="AutoX";;
2 ) FCTEXTAD1="Accumulator";;
3 ) FCTEXTAD1="Equalizer";;
4 ) FCTEXTAD1="Potency";;
5 ) FCTEXTAD1="Output";;
esac

ui_print ""
ui_print "[*] Selected: $FCTEXTAD1 "
ui_print ""

if [[ "$FCTEXTAD1" == "AutoX" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "4" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Accumulator" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "0" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Equalizer" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "1" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Potency" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "2" 2>/dev/null

elif [[ "$FCTEXTAD1" == "Output" ]]
then
stop x-auto
killall -q x-auto >/dev/null 2>&1&
setprop persist.xtweak.mode "3" 2>/dev/null
fi

ui_print " --- Additional Notes --- "
ui_print ""
ui_print "[*] Reboot is required"
ui_print ""
ui_print "[*] Do not use XTweak with other optimizer modules"
ui_print ""
ui_print "[*] (su -c x-menu) to open XTweak Menu in Termux"
ui_print ""
ui_print "[*] Report issues to @tweak_projects_discuss on Telegram"
ui_print ""
ui_print "[*] Contact @infinity_looper for direct support"
ui_print ""
sleep 4
ui_print "[*] Done!"
set_permissions
cleanup
}
#
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
  set_perm_recursive $MODPATH/system/xbin 0 0 0755 0755  
}
template_extras() {
# Only in recovery
if ! $BOOTMODE; then
  ui_print "[*] Only uninstall is supported in recovery"
  ui_print ""
  ui_print "[*] Uninstalling!"
  ui_print ""
  touch "$MODPATH"/remove
  [ -s "$INFO" ] && install_script "$MODPATH"/uninstall.sh || rm -f "$INFO" "$MODPATH"/uninstall.sh
  recovery_cleanup
  cleanup
  rm -rf "$NVBASE"/modules_update/"$MODID" "$TMPDIR" 2>/dev/null
  exit 0
fi
# Enable debug logs
set -x
}
