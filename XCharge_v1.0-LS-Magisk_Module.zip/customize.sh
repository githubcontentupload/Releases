#!/system/bin/sh
# Author is INFINITY LOOPER (InfinityLoop-er @ GitHub)
# Credits to Draco (tytydraco @ GitHub)

ui_print ""
ui_print " --- XCharge Magisk Module ---"
ui_print ""
ui_print " * Setting executable permissions..."
set_perm_recursive "$MODPATH/system/bin" root root 0777 0755

# Do install-time script execution
ui_print " * Executing during live boot..."
sh "$MODPATH/system/bin/xchargelightspeed" &> /dev/null

ui_print ""
ui_print " --- Additional Notes ---"
ui_print ""
ui_print " * Dirty flashes usually do not require a reboot"
ui_print " * Use XCharge at your own risk"
ui_print " * Report issues to @tweak_projects_discuss on Telegram"
ui_print " * Contact @infinity_looper for direct support"
ui_print ""
