#!/system/bin/sh
# Author is INFINITY LOOPER (InfinityLoop-er @ GitHub)
# Credits to Draco (tytydraco @ GitHub)
# Wait for boot to finish completely
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 1
done

# Sleep an additional 120s to ensure init is finished
sleep 120

# Run the script
xchargelightspeed
