#!/system/bin/sh
# XTweak by INFINITY LOOPER ( InfinityLoop-er @ GitHub)
# If you wanna use it as part of your project, please maintain the credits to it respective's author(s) as I did

# remove script before updating
if [[ -d "/data/adb/modules/xtweak" ]]; then
    rm -R "/data/adb/modules/xtweak/system/bin/xtweak"
fi

# update script after every reboot
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/accumulator/xtweak"
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/potency/xtweak"
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/equalizer/xtweak"
wget -O "$MODPATH"/system/bin/xtweak "https://raw.githubusercontent.com/InfinityLoop-er/XTweak/output/xtweak"

# Wait to boot be completed
while [[ `getprop sys.boot_completed` -ne 1 ]] && [[ ! -d "/sdcard" ]]
do
       sleep 2
done

# Sleep a additional time to make sure that the system will not override any of the modifications of the main script
sleep 30

# Fstrimming partitions
fstrim -v /system
fstrim -v /data
fstrim -v /cache
sm fstrim

# Run sqlite opt
if [[ "$(find /system -name "sqlite3" -type f)" ]]; then
    echo -e " Optimizing databases..." >> /sdcard/XTweak/sqlite_opt.log
    echo -e "" >> /sdcard/XTweak/sqlite_opt.log
for i in $(find /d* -iname "*.db"); do
sqlite3 "$i" 'VACUUM;'
resVac=$?
if [[ $resVac == "0" ]]; then
    resVac="SUCCESS"
else
    resVac="FAILED(ERRCODE)-$resVac"
fi
sqlite3 "$i" 'REINDEX;'
resIndex=$?
if [[ $resIndex == "0" ]]; then
    resIndex="SUCCESS"
else
    resIndex="FAILED(ERRCODE)-$resIndex"
fi
sqlite3 "$i" 'ANALYZE;'
    resAnlz=$?
    if [[ $resAnlz == "0" ]]; then
        resAnlz="SUCCESS"
    else
        resAnlz="FAILED(ERRCODE)-$resAnlz"
    fi
        echo -e "Database $i: VACUUM=$resVac REINDEX=$resIndex ANALYZE=$resAnlz" >> /sdcard/XTweak/sqlite.log
   done
fi

# Run zipalign opt
if [[ -e "/sdcard/XTweak/zipalign.log" ]]; then
	rm "/sdcard/XTweak/zipalign.log"
fi

if [[ ! -f "/sdcard/XTweak/zipalign.db" ]]; then
	touch "/sdcard/XTweak/zipalign.db"
fi

for DIR in /system/app/* /data/app/* /system/product/app/* /system/priv-app/* /system/product/priv-app/* /vendor/data-app/* /vendor/app/* /vendor/overlay /system/system_ext/app/* /system/system_ext/priv-app/*; do
   cd $DIR  
   for APK in *.apk; do
    if [[ "$APK" -ot "/sdcard/XTweak/zipalign.db" ]] && [[ "$(grep "$DIR/$APK" "/sdcard/XTweak/zipalign.db" | wc -l)" -gt 0 ]]; then
      echo -e "Already checked: $DIR/$APK" >> "/sdcard/XTweak/zipalign.log"
     else
      zipalign -c 4 "$APK"
      if [[ $? -eq 0 ]]; then
        echo -e "Already aligned: $DIR/$APK" >> "/sdcard/XTweak/zipalign.log"
        grep "$DIR/$APK" "/sdcard/XTweak/zipalign.db" || echo "$DIR/$APK" >> "/sdcard/XTweak/zipalign.db"
      else
        echo -e "Now aligning: $DIR/$APK" >> "/sdcard/XTweak/zipalign.log"
        cd $APK
        zipalign -f 4 "$APK" "/cache/$APK"
        cp -af -p "/cache/$APK" "$APK"
        rm -f "/cache/$APK"
        grep "$DIR/$APK" "/sdcard/XTweak/zipalign.db" || echo "$DIR/$APK" >> "/sdcard/XTweak/zipalign.db"
      fi
    fi
  done
done

# Ensure SF & SS performance by changing it's "priority"
for pid in $(pgrep -f surfaceflinger) $(pgrep -f system_server); do 
echo $pid > /dev/stune/foreground/tasks
echo $pid > /dev/cpuset/top-app/tasks
done

# Report max frequency to unity tasks 
echo "UnityMain,libunity.so" > /proc/sys/kernel/sched_lib_name
echo "255" > /proc/sys/kernel/sched_lib_mask_force

# Optimizing Android system
dumpsys deviceidle enable all
dumpsys deviceidle whitelist +com.android.systemui
settings put global dropbox_max_files 1
settings put system anr_debugging_mechanism 0
settings put global adaptive_battery_management_enabled 1
settings put global aggressive_battery_saver 1
settings put global enable_freeform_support 1
settings put global allow_signature_fake 1
settings put system display_color_enhance 1
settings delete global device_idle_constants
settings put global device_idle_constants inactive_to=60000,sensing_to=0,locating_to=0,location_accuracy=2000,motion_inactive_to=0,idle_after_inactive_to=0,idle_pending_to=60000,max_idle_pending_to=120000,idle_pending_factor=2.0,idle_to=900000,max_idle_to=21600000,idle_factor=2.0,max_temp_app_whitelist_duration=60000,mms_temp_app_whitelist_duration=30000,sms_temp_app_whitelist_duration=20000,light_after_inactive_to=10000,light_pre_idle_to=60000,light_idle_to=180000,light_idle_factor=2.0,light_max_idle_to=900000,light_idle_maintenance_min_budget=30000,light_idle_maintenance_max_budget=60000

if [[ "$(getprop ro.hwui.texture_cache_size)" ]] && [[ $total_ram -gt "3400" ]]; then
    echo "ro.hwui.texture_cache_size $((total_ram / 10 / 5))
    ro.hwui.layer_cache_size $((total_ram / 100 / 3 * 5))
    ro.hwui.path_cache_size $((total_ram / 100 / 2 * 2))
    ro.hwui.r_buffer_cache_size $((total_ram / 100 / 3))
    ro.hwui.drop_shadow_cache_size $((total_ram / 100 / 4))
    "
fi

cmd appops set com.android.backupconfirm RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.setupwizard RUN_IN_BACKGROUND ignore
cmd appops set com.android.printservice.recommendation RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.feedback RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.onetimeinitializer RUN_IN_BACKGROUND ignore
cmd appops set com.xiaomi.joyose RUN_IN_BACKGROUND ignore
cmd appops set com.android.traceur RUN_IN_BACKGROUND ignore
cmd appops set org.codeaurora.gps.gpslogsave RUN_IN_BACKGROUND ignore
cmd appops set com.android.onetimeinitializer RUN_IN_BACKGROUND ignore
cmd appops set com.qualcomm.qti.perfdump RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gms RUN_IN_BACKGROUND ignore
cmd appops set com.google.android.gsf RUN_IN_BACKGROUND ignore

# First, clean trash before exuecting main script
rm -f /data/*.log
rm -rf /data/vendor/wlan_logs
rm -f /data/*.txt
rm -f /cache/*.apk
rm -f /data/anr/*
rm -f /data/backup/pending/*.tmp
rm -f /data/cache/*.*
rm -f /data/data/*.log
rm -f /data/data/*.txt
rm -f /data/log/*.log
rm -f /data/log/*.txt
rm -f /data/local/*.apk
rm -f /data/local/*.log
rm -f /data/local/*.txt
rm -f /data/last_alog/*.log
rm -f /data/last_alog/*.txt
rm -f /data/last_kmsg/*.log
rm -f /data/last_kmsg/*.txt
rm -f /data/mlog/*
rm -f /data/system/*.log
rm -f /data/system/*.txt
rm -f /data/system/dropbox/*
rm -f /data/system/usagestats/*
rm -f /data/system/shared_prefs/*
rm -f /data/tombstones/* 
rm -rf /sdcard/LOST.DIR 
rm -rf /sdcard/found000
rm -rf /sdcard/LazyList 
rm -rf /sdcard/albumthumbs
rm -rf /sdcard/kunlun 
rm -rf /sdcard/.CacheOfEUI 
rm -rf /sdcard/.bstats 
rm -rf /sdcard/.taobao 
rm -rf /sdcard/Backucup 
rm -rf /sdcard/MIUI/debug_log
rm -rf /sdcard/ramdump
rm -rf /sdcard/UnityAdsVideoCache
rm -f /sdcard/*.log
rm -f /sdcard/*.CHK

# Apply tweak
xtweak