#!/system/bin/sh
# XTweak 2021
LATESTARTSERVICE=true
DEBUG=true
if [[ -e "/sdcard/KTSR" ]]; then
    rm -rf "/sdcard/KTSR"
fi
Path=/sdcard
if [ ! -d $Path/XTweak ]; then
 mkdir -p $Path/XTweak
fi
XT=$Path/XTweak
awk '{print}' "$MODPATH"/xtweak_banner
sleep 3.3
awk '{print}' "$MODPATH"/knight_banner
ui_print ""
sleep 3.3    
ui_print "[*] XTweak is a universal powerful forcefulness kernel tweaker."
ui_print ""
sleep 3.3
ui_print "[*] It will enhance the performance while conserving battery usage by adjusting various kernel parameters of your android device."
ui_print ""
sleep 3.3
ui_print "[*] If you really like my projects, consider sharing them with your friends. It means alot to me.♥️"
sleep 3.3
#
set_permissions() {
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
  set_perm_recursive $MODPATH/system/xbin 0 0 0755 0755  
  set_perm_recursive $MODPATH/system/vendor/etc 0 0 0755 0755 
}
SKIPUNZIP=0
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d "$TMPDIR" >&2
. "$TMPDIR"/functions.sh